(function () {
  var root = globalThis.FBQ = globalThis.FBQ || { installed: {} };
  if (root.installed.runnerUi) return;
  if (typeof chrome === 'undefined' || !chrome.storage || !chrome.tabs || !chrome.runtime || !chrome.notifications) {
    root.runnerUi = {};
    root.installed.runnerUi = 1;
    return;
  }

  var PORT_NAME = 'fbq';
  var LEASE_TTL_MS = 60000;
  var HEARTBEAT_MS = 20000;
  var POLL_MS = 5000;
  var NAV_TIMEOUT_MS = 20000;
  var PREPARE_TIMEOUT_MS = 300000;
  var POST_TIMEOUT_MS = 80000;
  var COOLDOWN_MS = 30 * 60 * 1000;
  var MAX_LOG_LINES = 300;

  var DEFAULT_SETTINGS = {
    minDelaySec: 60,
    maxDelaySec: 180,
    confirmWindowSec: 10,
    maxPerRun: 50,
    batchSize: 10,
    batchBreakSec: 1800,
    retryBeforeClick: 1,
    stopAfterConsecutiveFailures: 3
  };

  var STATE_LABELS = {
    queued: 'Chờ tới lượt',
    navigating: 'Đang mở trang FB...',
    preparing: 'Đang điền bài...',
    countdown: 'Đếm ngược...',
    clicking: 'Đang bấm Đăng...',
    image_uploading: 'Đang tải ảnh...',
    text_ok: 'Đã điền chữ',
    images_ok: 'Đã tải ảnh',
    posted: '✅ Đã đăng thành công',
    cancelled: '⏭ Đã hủy',
    needs_manual: '⚠️ Cần kiểm tra tay',
    failed: '❌ Lỗi'
  };

  var ERROR_LABELS = {
    rate_limited: 'Giới hạn đăng',
    nav_fail: 'Không mở được trang',
    nav_mismatch: 'Sai trang',
    post_failed: 'Đăng thất bại',
    post_disabled: 'Biểu mẫu bị khóa',
    insert_rejected: 'Bị chặn chèn nội dung',
    upload_rejected: 'Tải ảnh thất bại',
    timeline_url_missing: 'Thiếu URL timeline',
    content_timeout: 'Không kết nối được trang Facebook',
    composer_not_found: 'Không thấy ô soạn bài',
    editor_not_found: 'Không thấy khung soạn bài',
    image_input_not_found: 'Không thấy nút ảnh',
    scanner_not_ready: 'Bộ quét chưa sẵn sàng',
    no_port: 'Chưa nối được trang',
    stopped: 'Đã dừng',
    unknown: 'Lỗi không xác định'
  };

  var elStatus = null;
  var elProgress = null;
  var elEta = null;
  var elRows = null;
  var elLog = null;
  var elHint = null;
  var elBatch = null;
  var elBreak = null;
  var elBreakTime = null;
  var btnStart = null;
  var btnPause = null;
  var btnStop = null;
  var btnCloseTab = null;

  var hasOwn = Object.prototype.hasOwnProperty;
  var LOCAL = chrome.storage.local;
  var SESSION = chrome.storage.session;
  var RUNTIME = chrome.runtime;
  var TABS = chrome.tabs;
  var NOTIF = chrome.notifications;

  var state = {
    tabId: null,
    runId: null,
    epoch: null,
    port: null,
    portTabId: null,
    pending: {},
    nextReq: 1,
    groups: [],
    itemKeys: [],
    itemsByKey: {},
    settings: {},
    qmeta: null,
    phase: 'idle',
    pausing: false,
    stopping: false,
    navigatingItem: null,
    consecutiveFails: 0,
    delayUntil: 0,
    timers: {}
  };

  function now() { return Date.now(); }

  function localGet(keys) {
    return new Promise(function (resolve) {
      LOCAL.get(keys, function (items) { resolve(items || {}); });
    });
  }

  function localSet(items) {
    return new Promise(function (resolve) {
      LOCAL.set(items, function () { resolve(); });
    });
  }

  function localRemove(keys) {
    return new Promise(function (resolve) {
      LOCAL.remove(keys, function () { resolve(); });
    });
  }

  function sessionGet(key) {
    return new Promise(function (resolve) {
      SESSION.get(key, function (items) { resolve(items || {}); });
    });
  }

  function sessionSet(items) {
    return new Promise(function (resolve) {
      SESSION.set(items, function () { resolve(); });
    });
  }

  function log(msg) {
    if (!elLog) return;
    var d = new Date();
    var pad = function (n) { return n < 10 ? '0' + n : String(n); };
    var t = pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
    var lines = elLog.textContent ? elLog.textContent.split('\n') : [];
    lines.push('[' + t + '] ' + msg);
    if (lines.length > MAX_LOG_LINES) lines = lines.slice(lines.length - MAX_LOG_LINES);
    elLog.textContent = lines.join('\n');
    elLog.scrollTop = elLog.scrollHeight;
  }

  function setStatus(txt) {
    if (elStatus) elStatus.textContent = txt;
  }

  function escapeHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  function fmtTime(ms) {
    var d = new Date(ms);
    var pad = function (n) { return n < 10 ? '0' + n : String(n); };
    return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
  }

  function fmtSec(sec) {
    var m = Math.floor(sec / 60);
    var s = Math.floor(sec % 60);
    return m + 'p' + (s < 10 ? '0' : '') + s + 's';
  }

  function mergeSettings(s) {
    var out = {};
    var k;
    var safetyDefaults = (root.safety && root.safety.SAFETY_DEFAULTS) || {};
    for (k in DEFAULT_SETTINGS) {
      if (hasOwn.call(DEFAULT_SETTINGS, k)) out[k] = DEFAULT_SETTINGS[k];
    }
    for (k in safetyDefaults) {
      if (hasOwn.call(safetyDefaults, k)) out[k] = safetyDefaults[k];
    }
    if (s) {
      for (k in s) {
        if (hasOwn.call(s, k)) out[k] = s[k];
      }
    }
    return out;
  }

  function defaultQMeta() {
    if (root.schema && root.schema.defaultQMeta) return root.schema.defaultQMeta();
    return {
      schema: 1, runId: null, status: 'idle', startedAt: 0, finishedAt: 0,
      cursor: 0, total: 0, cancelKey: 0, abortReason: null, cooldownUntil: 0,
      snapshot: { text: '', imageIds: [], settings: {}, postId: '' }
    };
  }

  function defaultQItem(key, url) {
    if (root.schema && root.schema.defaultQItem) return root.schema.defaultQItem(key, url);
    return {
      key: key, url: url, state: 'queued', attemptNo: 0, variantIndex: 0,
      textResolved: '', textHash: '', clickedAt: 0, postedAt: 0,
      errorCode: null, errorText: null, lastStepAt: Date.now()
    };
  }

  function saveQmeta(qm) {
    return localSet({ qmeta: qm });
  }

  function saveItem(item) {
    var obj = {};
    obj['qitem:' + item.key] = item;
    return localSet(obj);
  }

  function updateBreakUI() {
    var nowT = now();
    var sec = 0;
    var qm = state.qmeta;
    if (state.phase === 'batch_break') {
      sec = Math.ceil((state.delayUntil - nowT) / 1000);
    } else if (qm && qm.cooldownUntil && qm.cooldownUntil > nowT) {
      sec = Math.ceil((qm.cooldownUntil - nowT) / 1000);
    }
    if (sec > 0) {
      if (elBreak) { elBreak.style.display = 'block'; }
      if (elBreakTime) { elBreakTime.textContent = fmtSec(Math.max(0, sec)); }
    } else if (elBreak) {
      elBreak.style.display = 'none';
    }
  }

  function render() {
    var qm = state.qmeta;
    var total = qm ? qm.total : 0;
    var counts = { posted: 0, failed: 0, cancelled: 0, unknown: 0, needs_manual: 0, queued: 0 };
    var k;
    for (k in state.itemsByKey) {
      if (!hasOwn.call(state.itemsByKey, k)) continue;
      if (hasOwn.call(counts, state.itemsByKey[k].state)) counts[state.itemsByKey[k].state]++;
      else counts.queued++;
    }
    var done = counts.posted + counts.failed + counts.cancelled + counts.unknown;
    var running = state.phase === 'running';

    if (elProgress) {
      elProgress.textContent = 'Tiến độ: ' + done + '/' + total +
        ' (đăng ' + counts.posted + ', lỗi ' + counts.failed +
        ', hủy ' + counts.cancelled + ', unknown ' + counts.unknown + ')';
    }
    if (elEta) {
      elEta.textContent = running ? 'ETA: ' + etaText() : 'ETA: —';
    }
    if (elBatch) {
      var batchSize = state.settings.batchSize || 10;
      var qm = state.qmeta;
      var cursor = qm ? qm.cursor : 0;
      var total = qm ? qm.total : 0;
      var batchIndex = Math.floor(cursor / batchSize) + 1;
      var totalBatches = Math.ceil(total / batchSize);
      var batchStart = (batchIndex - 1) * batchSize;
      var batchEnd = Math.min(batchIndex * batchSize, total);
      var postedInBatch = 0;
      var k;
      for (k = batchStart; k < batchEnd; k++) {
        var key = state.itemKeys[k];
        if (!key) continue;
        var it = state.itemsByKey[key];
        if (it && it.state === 'posted') postedInBatch++;
      }
      elBatch.textContent = 'Lô ' + batchIndex + '/' + totalBatches + ' • ' + postedInBatch + '/' + (batchEnd - batchStart) + ' bài';
    }
    if (elBreak) { updateBreakUI(); }
    if (elRows) {
      var html = '';
      var i;
      for (i = 0; i < state.itemKeys.length; i++) {
        k = state.itemKeys[i];
        var item = state.itemsByKey[k] || { state: 'queued', url: '', key: k };
        var group = state.groups[i] || {};
        html += '<tr>' +
          '<td>' + escapeHtml(group.name || k) + '</td>' +
          '<td class="url">' + escapeHtml(item.url || group.url || '') + '</td>' +
          '<td class="state">' + escapeHtml(STATE_LABELS[item.state] || item.state) + '</td>' +
          '<td>' + (item.lastStepAt ? fmtTime(item.lastStepAt) : '—') + '</td>' +
          '<td>' + escapeHtml(ERROR_LABELS[item.errorCode] || item.errorCode || '') + '</td>' +
          '<td class="open">' + (item.url ? '<button data-url="' + escapeHtml(item.url) + '">Mở trang</button>' : '') + '</td>' +
          '</tr>';
      }
      elRows.innerHTML = html;
    }
    setStatus(statusText());
  }

  function statusText() {
    switch (state.phase) {
      case 'running': return 'Đang chạy (' + state.runId + ')';
      case 'batch_break': return 'Nghỉ giữa lô';
      case 'paused': return 'Tạm dừng';
      case 'aborted': return 'Đã hủy toàn bộ';
      case 'resuming': return 'Sẵn sàng tiếp tục';
      default: return 'Sẵn sàng';
    }
  }

  function etaText() {
    var qm = state.qmeta;
    var settings = state.settings;
    var min = settings.minDelaySec || 60;
    var max = settings.maxDelaySec || 180;
    var perItem = (min + max) / 2 + 30;
    var remaining = 0;
    var k;
    for (k in state.itemsByKey) {
      if (!hasOwn.call(state.itemsByKey, k)) continue;
      var st = state.itemsByKey[k].state;
      if (st === 'queued' || st === 'navigating' || st === 'preparing' || st === 'countdown' || st === 'clicking') remaining++;
    }
    var sec = remaining * perItem;
    if (state.delayUntil > now()) sec += (state.delayUntil - now()) / 1000;
    if (sec <= 0) return '—';
    return '≈ ' + fmtSec(Math.ceil(sec));
  }

  function startHeartbeat() {
    stopHeartbeat();
    state.timers.heartbeat = setInterval(function () {
      var n = now();
      sessionSet({ lease: { owner: state.runId, heartbeatAt: n, until: n + LEASE_TTL_MS } });
    }, HEARTBEAT_MS);
  }

  function stopHeartbeat() {
    if (state.timers.heartbeat) {
      clearInterval(state.timers.heartbeat);
      state.timers.heartbeat = null;
    }
  }

  function releaseLease() {
    stopHeartbeat();
    SESSION.remove('lease', function () {});
  }

  function takeLease(runId, cb) {
    state.runId = runId;
    sessionGet('lease').then(function (items) {
      var lease = items.lease;
      var n = now();
      if (lease && lease.until > n && lease.owner !== runId) {
        return Promise.reject({ code: 'lease_held' });
      }
      return sessionSet({ lease: { owner: runId, heartbeatAt: n, until: n + LEASE_TTL_MS } });
    }).then(function () {
      startHeartbeat();
      cb(null);
    }).catch(function (err) {
      if (err && err.code === 'lease_held') { cb('lease_held'); return; }
      startHeartbeat();
      cb(null);
    });
  }

  function clearAllTimers() {
    var k;
    for (k in state.timers) {
      if (!hasOwn.call(state.timers, k)) continue;
      if (state.timers[k] !== null) {
        if (typeof state.timers[k].clear === 'function') state.timers[k].clear();
        else clearTimeout(state.timers[k]);
        state.timers[k] = null;
      }
    }
  }

  function startPoll() {
    stopPoll();
    state.timers.poll = setInterval(pollTab, POLL_MS);
    pollTab();
  }

  function stopPoll() {
    if (state.timers.poll) {
      clearInterval(state.timers.poll);
      state.timers.poll = null;
    }
  }

  function pollTab() {
    if (!state.tabId || state.phase === 'idle') return;
    TABS.get(state.tabId, function (tab) {
      if (chrome.runtime.lastError || !tab) {
        state.tabId = null;
        if (state.phase !== 'idle') pauseRun('tab_closed');
        return;
      }
      if (isAbortUrl(tab.url || '')) abortRun('checkpoint');
    });
  }

  function isAbortUrl(url) {
    try {
      var u = new URL(url);
    } catch (e) {
      return false;
    }
    var p = u.pathname || '';
    if (p.indexOf('/checkpoint') === 0) return true;
    if (u.href.indexOf('/login') !== -1) return true;
    return false;
  }

  function normalizeTimelineUrl(url) {
    var u = String(url == null ? '' : url).replace(/^\s+|\s+$/g, '');
    if (!u) return 'https://www.facebook.com/me';
    if (!/^https?:\/\//i.test(u)) u = 'https://www.facebook.com/' + u.replace(/^\/+/, '');
    return u;
  }

  function isTimelineUrl(url) {
    var u;
    try {
      u = new URL(normalizeTimelineUrl(url));
    } catch (e) {
      return false;
    }
    var host = (u.hostname || '').toLowerCase();
    if (host !== 'www.facebook.com' && host !== 'facebook.com') return false;
    var p = u.pathname || '/';
    if (p.indexOf('/groups/') === 0 || p.indexOf('/checkpoint') === 0 || p.indexOf('/login') === 0) return false;
    return true;
  }

  function abortRun(reason) {
    clearTimeout(state.timers.delay);
    state.timers.delay = null;
    state.phase = 'idle';
    state.pausing = false;
    state.stopping = false;
    state.navigatingItem = null;
    var qm = state.qmeta;
    if (qm) {
      qm.status = 'aborted';
      qm.abortReason = reason;
      qm.cooldownUntil = now() + (reason === 'rate_limited' ? 24 * 60 * 60 * 1000 : COOLDOWN_MS);
      saveQmeta(qm);
    }
    stopHeartbeat();
    releaseLease();
    stopPoll();
    if (state.tabId) {
      TABS.remove(state.tabId, function () {});
      state.tabId = null;
    }
    if (reason === 'rate_limited') {
      NOTIF.create('fbq-abort-' + now(), { type: 'basic', title: 'FB Group Poster', message: 'Facebook đang cảnh báo giới hạn đăng bài. Đã dừng và khoá 24 giờ.' });
      log('ABORT rate_limited: khoá 24 giờ');
      setStatus('Facebook đang cảnh báo giới hạn đăng bài. Đã dừng và khoá 24 giờ.');
    } else {
      NOTIF.create('fbq-abort-' + now(), { type: 'basic', title: 'FB Group Poster', message: 'Đã hủy toàn bộ: ' + reason });
      log('ABORT: ' + reason);
      setStatus('Aborted: ' + reason);
    }
    render();
  }

  function pauseRun(reason) {
    clearTimeout(state.timers.delay);
    state.timers.delay = null;
    state.phase = 'idle';
    state.pausing = false;
    state.stopping = false;
    state.navigatingItem = null;
    var qm = state.qmeta;
    if (qm) {
      qm.status = 'paused';
      qm.abortReason = qm.abortReason || reason;
      saveQmeta(qm);
    }
    log('PAUSE: ' + reason);
    setStatus('Tạm dừng: ' + reason);
    render();
  }

  function finishRun(status) {
    clearAllTimers();
    stopHeartbeat();
    stopPoll();
    releaseLease();
    var qm = state.qmeta;
    if (qm) {
      qm.status = status;
      qm.finishedAt = now();
      saveQmeta(qm);
    }
    if (state.tabId) {
      TABS.remove(state.tabId, function () {});
      state.tabId = null;
    }
    state.phase = 'idle';
    state.runId = null;
    state.navigatingItem = null;
    var counts = { posted: 0, failed: 0, cancelled: 0, unknown: 0 };
    var k;
    for (k in state.itemsByKey) {
      if (!hasOwn.call(state.itemsByKey, k)) continue;
      if (hasOwn.call(counts, state.itemsByKey[k].state)) counts[state.itemsByKey[k].state]++;
    }
    NOTIF.create('fbq-finish-' + now(), {
      type: 'basic',
      title: 'FB Group Poster',
      message: 'Hoàn tất: đăng ' + counts.posted + ', lỗi ' + counts.failed + ', hủy ' + counts.cancelled + ', unknown ' + counts.unknown
    });
    log('Kết thúc (' + status + '): đăng ' + counts.posted + ', lỗi ' + counts.failed + ', hủy ' + counts.cancelled + ', unknown ' + counts.unknown);
    if (status === 'daily_cap') {
      setStatus('Xong hạn mức hôm nay (' + state.settings.dailyCap + ' bài)...');
    } else {
      setStatus('Hoàn tất (' + status + ')');
    }
    render();
  }

  function countState(st) {
    var n = 0;
    var k;
    for (k in state.itemsByKey) {
      if (!hasOwn.call(state.itemsByKey, k)) continue;
      if (state.itemsByKey[k].state === st) n++;
    }
    return n;
  }

  function urlsMatch(a, b) {
    if (!a || !b) return false;
    var ua = a.split('?')[0].split('#')[0];
    var ub = b.split('?')[0].split('#')[0];
    while (ua.length > 0 && ua.charAt(ua.length - 1) === '/') ua = ua.slice(0, -1);
    while (ub.length > 0 && ub.charAt(ub.length - 1) === '/') ub = ub.slice(0, -1);
    if (ua === ub) return true;
    return ua.indexOf(ub) === 0 || ub.indexOf(ua) === 0;
  }

  function openTabAt(url) {
    state.port = null;
    state.portTabId = null;
    return new Promise(function (resolve) {
      if (state.tabId) {
        TABS.update(state.tabId, { url: url, active: true, autoDiscardable: false }, function () {
          resolve();
        });
      } else {
        TABS.create({ url: url, active: true, autoDiscardable: false }, function (tab) {
          state.tabId = tab ? tab.id : null;
          resolve();
        });
      }
    });
  }

  function waitForContent(item, cb) {
    var deadline = now() + 30000;
    if (state.timers.content) { clearTimeout(state.timers.content); state.timers.content = null; }
    function tick() {
      state.timers.content = null;
      if (state.stopping) { cb({ code: 'stopped' }); return; }
      if (!state.tabId) { cb({ code: 'no_tab' }); return; }
      TABS.get(state.tabId, function (tab) {
        void RUNTIME.lastError;
        var tabUrl = (tab && tab.url) || '';
        var arrived = item.isTimeline
          ? (tabUrl.indexOf('facebook.com') !== -1 && !isAbortUrl(tabUrl))
          : urlsMatch(tabUrl, item.url);
        if (arrived && state.port && state.portTabId === state.tabId) { cb(null); return; }
        if (now() > deadline) { cb({ code: 'content_timeout' }); return; }
        if (arrived && !state.port) {
          try { TABS.sendMessage(state.tabId, { v: 1, type: 'fbq:connect' }, function () { void RUNTIME.lastError; }); } catch (e) {}
        }
        state.timers.content = setTimeout(tick, 400);
      });
    }
    tick();
  }

  function focusTab() {
    if (state.tabId) TABS.update(state.tabId, { active: true });
  }

  function sendToContent(type, payload, cb, timeoutMs) {
    if (!state.port) {
      if (cb) cb({ code: 'no_port' });
      return;
    }
    var req = String(state.nextReq++);
    var env = {
      v: 1,
      runId: state.runId || null,
      epoch: state.epoch || null,
      requestId: req,
      type: type,
      payload: payload || {}
    };
    state.pending[req] = { resolve: cb, timer: null };
    state.pending[req].timer = setTimeout(function () {
      var p = state.pending[req];
      if (p) {
        delete state.pending[req];
        if (cb) cb({ code: 'timeout' });
      }
    }, timeoutMs || 30000);
    state.port.postMessage(env);
  }

  function onPortMessage(env) {
    if (!env || env.v !== 1) return;
    var req = env.requestId;
    var pend = req && state.pending[req];
    if (!pend) return;
    delete state.pending[req];
    clearTimeout(pend.timer);
    if (env.type === 'error') pend.resolve({ code: (env.payload && env.payload.code) || 'error', message: env.payload && env.payload.message }, null);
    else pend.resolve(null, { type: env.type, payload: env.payload || {}, observedUrl: env.observedUrl });
  }

  RUNTIME.onConnect.addListener(function (p) {
    var senderTabId = p.sender && p.sender.tab ? p.sender.tab.id : null;
    if (state.tabId && senderTabId !== state.tabId) {
      log('Bỏ qua port từ tab ' + senderTabId);
      return;
    }
    state.port = p;
    state.portTabId = senderTabId;
    p.onMessage.addListener(onPortMessage);
    p.onDisconnect.addListener(function () {
      if (state.port === p) {
        state.port = null;
        state.portTabId = null;
        log('Mất kết nối nội dung');
      }
    });
    var it = state.navigatingItem;
    if (it) {
      state.navigatingItem = null;
      sendPing(it);
    }
  });

  TABS.onRemoved.addListener(function (tabId) {
    if (tabId === state.tabId) {
      state.tabId = null;
      if (state.phase !== 'idle') pauseRun('tab_closed');
    }
  });

  function sendPing(item) {
    if (!state.port) {
      state.navigatingItem = item;
      return;
    }
    state.navigatingItem = null;
    sendToContent('ping', { expectedKey: item.key }, function (err, res) {
      if (err) { onNavFail(item, err); return; }
      var observed = (res && res.observedUrl) || '';
      var matchOk = item.isTimeline ? (observed.indexOf('facebook.com') !== -1 && !isAbortUrl(observed)) : urlsMatch(observed, item.url);
      if (!matchOk) {
        onNavFail(item, { code: 'nav_mismatch', message: 'observed ' + observed });
        return;
      }
      item.state = 'preparing';
      item.lastStepAt = now();
      saveItem(item).then(function () { render(); runPrepare(item); });
    }, NAV_TIMEOUT_MS);
  }

  function onNavFail(item, err) {
    var code = (err && err.code) || String(err);
    var retries = state.settings.retryBeforeClick || 0;
    if (code === 'nav_mismatch' && item.attemptNo <= retries) {
      log('Lỗi định hướng, thử lại: ' + item.key);
      item.state = 'queued';
      saveItem(item).then(processQueue);
      return;
    }
    item.state = 'failed';
    item.errorCode = code || 'nav_fail';
    item.errorText = err && err.message ? err.message : '';
    item.lastStepAt = now();
    saveItem(item).then(function () { recordResult(item); });
  }

  function runItem(item) {
    state.phase = 'running';
    item.state = 'navigating';
    item.attemptNo = (item.attemptNo || 0) + 1;
    item.lastStepAt = now();
    saveItem(item).then(function () {
      render();
      state.epoch = now();
      openTabAt(item.url).then(function () {
        waitForContent(item, function (err) {
          if (err) { onNavFail(item, err); return; }
          sendPing(item);
        });
      });
    });
  }

  function processQueue() {
    if (state.stopping) { finishRun('stopped'); return; }
    if (state.pausing) { pauseRun('user'); return; }
    var qm = state.qmeta;
    if (!qm) { finishRun('idle'); return; }
    var keys = state.itemKeys;
    var start = qm.cursor || 0;
    var i;
    var key;
    var item;
    for (i = start; i < keys.length; i++) {
      key = keys[i];
      item = state.itemsByKey[key];
      if (!item) continue;
      if (item.state === 'queued') {
        qm.cursor = i;
        saveQmeta(qm).then(function () { runItem(item); });
        return;
      }
    }
    finishRun('done');
  }

  function resolveImages(imageIds, cb) {
    var list = [];
    var idx = 0;
    var openDB = root.assets && root.assets.openDB;
    if (!openDB) { cb(list); return; }
    openDB(function (db) {
      if (!db) { cb(list); return; }
      next();
    });
    function next() {
      if (idx >= imageIds.length) { cb(list); return; }
      root.assets.getAsset(db, imageIds[idx], function (err, asset) {
        if (asset && asset.blob) {
          blobToBase64(asset.blob, function (b64) {
            if (b64) {
              list.push({ b64: b64, mime: asset.mime || 'image/png', name: asset.name || ('img-' + idx) });
            }
            idx++;
            next();
          });
        } else {
          idx++;
          next();
        }
      });
    }
  }

  function blobToBase64(blob, cb) {
    var fr = new FileReader();
    fr.onload = function () {
      var url = fr.result;
      var idx = url ? url.indexOf(',') : -1;
      cb(idx >= 0 ? url.slice(idx + 1) : null);
    };
    fr.onerror = function () { cb(null); };
    fr.readAsDataURL(blob);
  }

  function runPrepare(item) {
    state.phase = 'preparing';
    item.state = 'preparing';
    item.lastStepAt = now();
    saveItem(item).then(function () {
      render();
      var qm = state.qmeta;
      var rawText = (qm && qm.snapshot && qm.snapshot.text) || '';
      var text = rawText;
      var totalVariants = 0;
      var seed = 0;
      if (root.safety) {
        seed = root.safety.textSeedForTarget(qm.runId, item.key);
        text = root.safety.resolveText(rawText, seed);
        totalVariants = root.safety.variantCount(rawText);
        item.variantIndex = totalVariants > 0 ? (seed % totalVariants) : 0;
        item.textResolved = text;
        var imageIds = root.safety.shuffle((qm && qm.snapshot && qm.snapshot.imageIds) || [], Math.random);
      } else {
        if (root.spintax && root.hash) {
          seed = root.hash.fnv1a(String(item.key || 'timeline') + '|' + String(state.runId || ''));
          try {
            text = root.spintax.render(root.spintax.parse(rawText), seed);
          } catch (e) {
            text = rawText;
          }
        }
        item.variantIndex = 0;
        item.textResolved = text;
        var imageIds = (qm && qm.snapshot && qm.snapshot.imageIds) || [];
      }
      resolveImages(imageIds, function (list) {
        item.state = list.length ? 'image_uploading' : 'text_ok';
        item.lastStepAt = now();
        saveItem(item).then(function () { render(); sendPrepareStream(item, text, list, 0); });
      });
    });
  }

  function sendPrepareStream(item, text, list, index) {
    if (list.length === 0 && index === 0) {
      sendToContent(item.isTimeline ? 'prepare_timeline' : 'prepare', {
        text: text,
        images: [],
        opts: { confirmWindowSec: state.settings.confirmWindowSec }
      }, function (err) {
        if (err) { onPrepareFail(item, err); return; }
        item.state = 'text_ok';
        item.lastStepAt = now();
        saveItem(item).then(function () { render(); runPost(item); });
      }, PREPARE_TIMEOUT_MS);
      return;
    }
    if (index >= list.length) {
      item.state = list.length ? 'images_ok' : 'text_ok';
      item.lastStepAt = now();
      saveItem(item).then(function () { render(); runPost(item); });
      return;
    }
    var img = list[index];
    var payload = {
      text: index === 0 ? text : '',
      images: [ { idx: index, total: list.length, b64: img.b64, mime: img.mime, name: img.name } ],
      opts: { confirmWindowSec: state.settings.confirmWindowSec }
    };
    sendToContent(item.isTimeline ? 'prepare_timeline' : 'prepare', payload, function (err, res) {
      if (err) { onPrepareFail(item, err); return; }
      if (res && res.type === 'prepared') {
        sendPrepareStream(item, text, list, index + 1);
      } else {
        sendPrepareStream(item, text, list, index + 1);
      }
    }, PREPARE_TIMEOUT_MS);
  }

  function onPrepareFail(item, err) {
    var code = (err && err.code) || String(err);
    var manualCodes = { insert_rejected: 1, upload_rejected: 1, post_disabled: 1 };
    var retries = state.settings.retryBeforeClick || 0;
    if (!manualCodes[code] && item.attemptNo <= retries) {
      log('Lỗi chuẩn bị, thử lại: ' + code + ' (' + item.key + ')');
      item.state = 'queued';
      saveItem(item).then(processQueue);
      return;
    }
    item.state = manualCodes[code] ? 'needs_manual' : 'failed';
    item.errorCode = code;
    item.errorText = err && err.message ? err.message : String(code);
    item.lastStepAt = now();
    saveItem(item).then(function () { recordResult(item); });
  }

  function runPost(item) {
    state.phase = 'countdown';
    item.state = 'countdown';
    item.lastStepAt = now();
    saveItem(item).then(function () {
      // COMMIT POINT: ghi clickedAt trước khi gửi lệnh post đến content script.
      item.clickedAt = now();
      item.attemptNo = (item.attemptNo || 0) + 1;
      item.state = 'clicking';
      item.lastStepAt = now();
      return saveItem(item);
    }).then(function () {
      render();
      sendToContent(item.isTimeline ? 'post_timeline' : 'post', {
        cancelKey: (state.qmeta && state.qmeta.cancelKey) || 0,
        clickedAt: item.clickedAt,
        confirmWindowSec: state.settings.confirmWindowSec
      }, function (err, res) {
        onPostResult(item, err, res);
      }, POST_TIMEOUT_MS);
    });
  }

  function onPostResult(item, err, res) {
    if ((err && err.code === 'rate_limited') || (res && res.payload && res.payload.errorCode === 'rate_limited')) {
      abortRun('rate_limited');
      return;
    }
    if (err) {
      var code = err.code || 'post_error';
      var manualCodes = { insert_rejected: 1, upload_rejected: 1, post_disabled: 1 };
      var retries = state.settings.retryBeforeClick || 0;
      if (!manualCodes[code] && item.attemptNo <= retries) {
        log('Lỗi trước khi đăng, thử lại: ' + code + ' (' + item.key + ')');
        item.state = 'queued';
        saveItem(item).then(processQueue);
        return;
      }
      item.state = manualCodes[code] ? 'needs_manual' : 'failed';
      item.errorCode = code;
      item.errorText = err && err.message ? err.message : String(code);
      item.lastStepAt = now();
      saveItem(item).then(function () { recordResult(item); });
      return;
    }
    var type = res && res.type;
    if (type === 'posted') {
      item.state = 'posted';
      item.postedAt = now();
      item.lastStepAt = now();
      state.consecutiveFails = 0;
      log('Đăng thành công: ' + item.key);
      if (root.safety && item.isTimeline !== true) {
        var dk = root.safety.dayKey(now());
        var dkName = 'safe:day:' + dk;
        var nNow = now();
        localGet([dkName, 'grp:' + item.key]).then(function (all2) {
          var rec = all2[dkName] || { count: 0 };
          rec.count = (rec.count || 0) + 1;
          var g = all2['grp:' + item.key];
          if (!g) g = { key: item.key };
          g.lastPostedAt = nNow;
          var sets = {};
          sets[dkName] = rec;
          sets['grp:' + item.key] = g;
          return localSet(sets).then(function () {
            return rec;
          });
        }).then(function (dayRec) {
          var remaining = root.safety.remainingToday(dayRec, state.settings.dailyCap);
          if (remaining <= 0) {
            finishRun('daily_cap');
            return;
          }
          saveItem(item).then(function () { recordResult(item); });
        });
        return;
      }
    } else if (type === 'cancelled') {
      item.state = 'cancelled';
      item.lastStepAt = now();
      log('Đã hủy: ' + item.key);
    } else if (type === 'failed') {
      item.state = 'failed';
      item.errorCode = (res && res.payload && res.payload.errorCode) || 'post_failed';
      item.errorText = (res && res.payload && res.payload.errorText) || '';
      item.lastStepAt = now();
      state.consecutiveFails++;
      log('Đăng thất bại: ' + item.key + ' (' + item.errorCode + ')');
    } else {
      item.state = 'unknown';
      item.lastStepAt = now();
      log('Không xác nhận: ' + item.key);
    }
    saveItem(item).then(function () { recordResult(item); });
  }

  function recordResult(item) {
    render();
    if (state.stopping) { finishRun('stopped'); return; }
    if (state.pausing) { pauseRun('user'); return; }
    var qm = state.qmeta;
    if (item.state === 'failed' && state.consecutiveFails >= (state.settings.stopAfterConsecutiveFailures || 3)) {
      pauseRun('consecutive_failures');
      return;
    }
    scheduleNext();
  }

  function scheduleNext() {
    if (state.stopping) { finishRun('stopped'); return; }
    if (state.pausing) { pauseRun('user'); return; }
    var settings = state.settings;
    var min = settings.minDelaySec || 60;
    var max = settings.maxDelaySec || 180;
    var sec = root.safety && typeof root.safety.chooseDelaySec === 'function' ? root.safety.chooseDelaySec(settings, Math.random) : (min + Math.floor(Math.random() * (max - min + 1)));
    state.delayUntil = now() + sec * 1000;
    log('Đợi ' + sec + 's trước group tiếp theo...');
    setStatus('Đợi ' + sec + 's');
    clearTimeout(state.timers.delay);
    state.timers.delay = setTimeout(processQueue, sec * 1000);
    render();
  }

  function loadItems() {
    return localGet(null).then(function (all) {
      var keys = Object.keys(all);
      var groups = [];
      var itemsByKey = {};
      var i;
      var k;
      var v;
      var key;
      for (i = 0; i < keys.length; i++) {
        k = keys[i];
        if (k.indexOf('grp:') === 0) {
          v = all[k];
          if (v && v.enabled !== false) {
            groups.push({ key: v.key || k.slice(4), url: v.url, name: v.name || '', lastPostedAt: v.lastPostedAt || 0 });
          }
        } else if (k.indexOf('qitem:') === 0) {
          v = all[k];
          if (v) {
            key = v.key || k.slice(6);
            itemsByKey[key] = v;
          }
        }
      }
      state.groups = groups;
      state.itemKeys = groups.map(function (g) { return g.key; });
      state.itemsByKey = itemsByKey;

      var qm = state.qmeta;
      if (qm) {
        for (i = 0; i < state.itemKeys.length; i++) {
          key = state.itemKeys[i];
          var item = itemsByKey[key];
          if (!item) continue;
          if (item.state === 'countdown') item.state = 'queued';
          else if (item.state === 'clicking' && item.clickedAt) item.state = 'unknown';
          else if (item.state === 'navigating' || item.state === 'preparing') item.state = 'queued';
          saveItem(item);
        }
        if (qm.status === 'running') state.phase = 'resuming';
      }
    });
  }

  function beginNewRun() {
    var groups = state.groups.filter(function (g) { return g.enabled !== false; });
    var settings = state.settings || {};
    var timelineUrl = normalizeTimelineUrl(settings.timelineUrl || '');
    var targetMode = settings.targetMode || (settings.postToTimeline && !groups.length ? 'timeline' : 'groups');
    var postToTimeline = targetMode === 'timeline' ? true : settings.postToTimeline === true;
    if (targetMode === 'groups' && !groups.length && !postToTimeline) {
      setStatus('Không có group nào để chạy');
      log('Không có group đã bật');
      return;
    }
    takeLease('r-' + now(), function (err) {
      if (err) {
        setStatus('Đang có phiên chạy khác');
        log('Không thể Start: phiên khác đang giữ lease');
        return;
      }
      var nowT = now();
      var todayKey = root.safety ? root.safety.dayKey(nowT) : null;
      var getKeys = ['settings'];
      if (root.safety && todayKey) getKeys.push('safe:day:' + todayKey);
      localGet(getKeys).then(function (all) {
        state.settings = mergeSettings(all.settings);
        settings = state.settings;
        timelineUrl = normalizeTimelineUrl(settings.timelineUrl || '');
        targetMode = settings.targetMode || (settings.postToTimeline && !groups.length ? 'timeline' : 'groups');
        postToTimeline = targetMode === 'timeline' ? true : settings.postToTimeline === true;
        var remaining = Infinity;
        if (root.safety && todayKey) {
          remaining = root.safety.remainingToday(all['safe:day:' + todayKey], settings.dailyCap);
          if (remaining <= 0) {
            setStatus('Hôm nay đã đăng đủ ' + settings.dailyCap + ' bài. Hẹn lại ngày mai!');
            log('Dừng chạy: hết hạn mức hàng ngày (' + settings.dailyCap + ')');
            stopHeartbeat();
            releaseLease();
            return;
          }
        }
        var picked = groups;
        if (root.safety) {
          if (targetMode === 'groups') {
            var eligibleList = root.safety.filterEligible(groups, nowT, settings).eligible;
            picked = root.safety.shuffle(eligibleList, Math.random).slice(0, Math.min(remaining, settings.maxPerRun || 50));
            if (!picked.length && !postToTimeline) {
              if (groups.length === 0) {
                setStatus('Không có group nào để chạy');
                log('Không có group đã bật');
              } else {
                setStatus('Tất cả ' + groups.length + ' nhóm đều đang trong thời gian nghỉ chờ');
                log('Dừng: toàn bộ nhóm đang cooldown hoặc hết lượt');
              }
              stopHeartbeat();
              releaseLease();
              return;
            }
          } else {
            picked = [];
          }
        }
        var postId = state.settings.activePostId || '';
        var getPromise = postId ? localGet(['post:' + postId]).then(function (all2) { return all2['post:' + postId]; }) : Promise.resolve(null);
        getPromise.then(function (post) {
          var qm = defaultQMeta();
          qm.schema = 1;
          qm.runId = state.runId;
          qm.status = 'running';
          qm.startedAt = now();
          qm.cursor = 0;
          qm.total = picked.length + (postToTimeline ? 1 : 0);
          qm.cancelKey = 0;
          qm.abortReason = null;
          qm.cooldownUntil = 0;
          qm.snapshot = {
            text: post ? post.text : '',
            imageIds: post ? (post.imageIds || []).slice(0, 10) : [],
            settings: mergeSettings(all.settings),
            postId: postId || ''
          };
          state.qmeta = qm;
          state.itemKeys = picked.map(function (g) { return g.key; });
          state.itemsByKey = {};
          var i;
          var sets = {};
          var item;
          for (i = 0; i < picked.length; i++) {
            item = defaultQItem(picked[i].key, picked[i].url);
            state.itemsByKey[item.key] = item;
            sets['qitem:' + item.key] = item;
          }
          if (postToTimeline) {
            item = defaultQItem('timeline', timelineUrl);
            item.isTimeline = true;
            if (!timelineUrl || !isTimelineUrl(timelineUrl)) {
              item.state = 'needs_manual';
              item.errorCode = 'timeline_url_missing';
              item.errorText = 'URL timeline không hợp lệ hoặc bị bỏ trống';
              item.lastStepAt = now();
            }
            state.itemsByKey[item.key] = item;
            state.itemKeys.push(item.key);
            sets['qitem:' + item.key] = item;
          }
          saveQmeta(qm).then(function () {
            return localSet(sets);
          }).then(function () {
            render();
            var firstKey = state.itemKeys[0];
            return openTabAt(state.itemsByKey[firstKey].url);
          }).then(function () {
            processQueue();
          });
        });
      });
    });
  }

  function resumeRun() {
    takeLease(state.runId, function (err) {
      if (err) {
        setStatus('Đang có phiên chạy khác');
        return;
      }
      state.phase = 'running';
      setStatus('Đang chạy (' + state.runId + ')');
      render();
      processQueue();
    });
  }

  function onStart() {
    if (state.phase === 'running') {
      focusTab();
      return;
    }
    if (state.phase === 'resuming') {
      resumeRun();
      return;
    }
    beginNewRun();
  }

  function onPause() {
    state.pausing = true;
    log('Pause: dừng sau bài hiện tại');
    setStatus('Pause');
  }

  function onStop() {
    state.stopping = true;
    var qm = state.qmeta;
    if (qm) {
      qm.cancelKey = (qm.cancelKey || 0) + 1;
      saveQmeta(qm);
    }
    log('Dừng tất cả: yêu cầu hủy bài hiện tại');
    setStatus('Đang dừng...');
    if (state.phase === 'idle') finishRun('stopped');
  }

  function onCloseTab() {
    if (!state.tabId) return;
    TABS.remove(state.tabId, function () {
      state.tabId = null;
    });
  }

  function init() {
    elStatus = document.getElementById('runner-status');
    elProgress = document.getElementById('runner-progress');
    elEta = document.getElementById('runner-eta');
    elRows = document.getElementById('runner-item-rows');
    elLog = document.getElementById('runner-log');
    elHint = document.getElementById('runner-hint');
    elBatch = document.getElementById('runner-batch');
    elBreak = document.getElementById('runner-break');
    elBreakTime = document.getElementById('runner-break-time');
    btnStart = document.getElementById('btn-start');
    btnPause = document.getElementById('btn-pause');
    btnStop = document.getElementById('btn-stop');
    btnCloseTab = document.getElementById('btn-close-tab');

    btnStart.addEventListener('click', onStart);
    btnPause.addEventListener('click', onPause);
    btnStop.addEventListener('click', onStop);
    btnCloseTab.addEventListener('click', onCloseTab);

    RUNTIME.onMessage.addListener(function (msg) {
      if (msg && msg.type === 'fbq:start-run') {
        localGet(['settings']).then(function (all) {
          state.settings = mergeSettings(all.settings);
          loadItems().then(function () {
            if (state.phase === 'idle') beginNewRun();
          });
        });
        return true;
      }
      if (msg && msg.type === 'fbq:stop-run') {
        onStop();
        return true;
      }
    });

    localGet(['qmeta', 'settings', 'autostartPending']).then(function (all) {
      var qm = all.qmeta;
      if (qm && (qm.status === 'running' || qm.status === 'paused')) {
        state.qmeta = qm;
        state.runId = qm.runId;
        state.settings = mergeSettings(all.settings);
        state.phase = qm.status === 'running' ? 'resuming' : 'idle';
        log('Phục hồi phiên ' + state.runId + ' (' + qm.status + ')');
      } else {
        state.settings = mergeSettings(all.settings);
      }
      loadItems().then(function () {
        var wantStart = (location.search.indexOf('autostart=1') !== -1) || (all.autostartPending === true);
        if (wantStart) {
          localSet({ autostartPending: false });
          history.replaceState(null, '', location.pathname);
        }
        state.tabId = null;
        state.port = null;
        state.portTabId = null;
        render();
        startPoll();
        setInterval(render, 1000);
        if (wantStart && state.phase === 'idle') beginNewRun();
      });
    });
  }

  init();

  root.runnerUi = {
    start: onStart,
    pause: onPause,
    stop: onStop,
    status: function () { return state.phase; },
    qmeta: function () { return state.qmeta; }
  };
  root.installed.runnerUi = 1;
})();
if (typeof process !== 'undefined' && process.versions && process.versions.node) {
  module.exports = globalThis.FBQ.runnerUi;
}
